package com.example.jogomemoria;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Collections;

public class Tela03 extends AppCompatActivity {

    TextView nomeJogador;
    Button btnJogadas, btnReiniciar;

    ImageView[] cartas = new ImageView[8];
    ArrayList<Integer> imagens = new ArrayList<>();

    int primeira = -1;
    int segunda = -1;

    int jogadas = 0;
    int pares = 0;

    boolean bloqueado = false;
    String nome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela03);

        nomeJogador = findViewById(R.id.textView_nome);
        btnJogadas = findViewById(R.id.btnJogadas);
        btnReiniciar = findViewById(R.id.btnReiniciar);

        nome = getIntent().getStringExtra("nome");
        nomeJogador.setText("Jogador: " + nome);

        cartas[0] = findViewById(R.id.imageView1);
        cartas[1] = findViewById(R.id.imageView2);
        cartas[2] = findViewById(R.id.imageView3);
        cartas[3] = findViewById(R.id.imageView4);
        cartas[4] = findViewById(R.id.imageView5);
        cartas[5] = findViewById(R.id.imageView6);
        cartas[6] = findViewById(R.id.imageView7);
        cartas[7] = findViewById(R.id.imageView8);

        iniciarJogo();
        mostrarCartasPorTempo();

        for (int i = 0; i < cartas.length; i++) {
            int index = i;
            cartas[i].setOnClickListener(v -> virarCarta(index));
        }

        btnReiniciar.setOnClickListener(v -> {
            iniciarJogo();
            mostrarCartasPorTempo();
        });
    }

    private void iniciarJogo() {

        imagens.clear();

        imagens.add(R.drawable.transilvanian_hunger);
        imagens.add(R.drawable.transilvanian_hunger);

        imagens.add(R.drawable.blade_and_bath);
        imagens.add(R.drawable.blade_and_bath);

        imagens.add(R.drawable.psychonaut_4);
        imagens.add(R.drawable.psychonaut_4);

        imagens.add(R.drawable.dymna_lotva);
        imagens.add(R.drawable.dymna_lotva);

        Collections.shuffle(imagens);

        for (ImageView carta : cartas) {
            carta.setImageResource(R.drawable.ic_action_name_2);
            carta.setEnabled(true);
        }

        primeira = -1;
        segunda = -1;
        jogadas = 0;
        pares = 0;
        bloqueado = false;

        btnJogadas.setText("Jogadas: 0");
    }

    private void mostrarCartasPorTempo() {

        for (int i = 0; i < cartas.length; i++) {
            cartas[i].setImageResource(imagens.get(i));
            cartas[i].setEnabled(false);
        }

        new Handler().postDelayed(() -> {
            for (ImageView carta : cartas) {
                carta.setImageResource(R.drawable.ic_action_name_2);
                carta.setEnabled(true);
            }
        }, 5000);
    }

    private void virarCarta(int index) {

        if (bloqueado) return;

        ImageView carta = cartas[index];


        carta.setImageResource(imagens.get(index));

        if (primeira == -1) {
            primeira = index;

        } else if (segunda == -1 && index != primeira) {

            segunda = index;
            bloqueado = true;
            jogadas++;

            btnJogadas.setText("Jogadas: " + jogadas);

            new Handler().postDelayed(this::verificarPar, 1000);
        }
    }

    private void verificarPar() {

        if (imagens.get(primeira).equals(imagens.get(segunda))) {

            cartas[primeira].setEnabled(false);
            cartas[segunda].setEnabled(false);
            pares++;

            if (pares == 4) {
                Intent i = new Intent(Tela03.this, Tela04.class);
                i.putExtra("nome", nome);
                i.putExtra("jogadas", jogadas);
                startActivity(i);
                finish();
            }

        } else {
            cartas[primeira].setImageResource(R.drawable.ic_action_name_2);
            cartas[segunda].setImageResource(R.drawable.ic_action_name_2);
        }

        primeira = -1;
        segunda = -1;
        bloqueado = false;
    }
}
