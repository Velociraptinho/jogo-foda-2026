package com.example.jogomemoria;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Tela04 extends AppCompatActivity {

    TextView textParabens, textNomeFinal, textJogadasFinal;
    Button btnJogarNovamente;
    ImageView imgParabens;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tela04);

        textParabens = findViewById(R.id.textParabens);
        textNomeFinal = findViewById(R.id.textNomeFinal);
        textJogadasFinal = findViewById(R.id.textJogadasFinal);
        btnJogarNovamente = findViewById(R.id.btnJogarNovamente);
        imgParabens = findViewById(R.id.imageView);

        Bundle caixa = getIntent().getExtras();
        if (caixa != null) {
            String nome = caixa.getString("nome");
            int jogadas = caixa.getInt("jogadas");

            textNomeFinal.setText(nome);
            textJogadasFinal.setText("Jogadas: " + jogadas);
        }

        btnJogarNovamente.setOnClickListener(v -> {
            Intent i = new Intent(Tela04.this, Tela02.class);
            startActivity(i);
            finish();
        });
    }
}
