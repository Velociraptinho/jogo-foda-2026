package com.example.jogomemoria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Tela02 extends AppCompatActivity implements View.OnClickListener{
    private EditText caixaNome;
    private Button btnIr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela02);

        caixaNome = findViewById(R.id.editText_nome);
        btnIr = findViewById(R.id.button_ir);
        btnIr.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        if (v == btnIr) {
            Intent i = new Intent(this, Tela03.class);

            Bundle caixa = new Bundle();
            caixa.putString("nome", caixaNome.getText().toString());
            i.putExtras(caixa);

            startActivity(i);
        }

    }
}