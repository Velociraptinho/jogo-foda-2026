package com.example.jogomemoria;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
    private Button btn_entrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_entrar = findViewById(R.id.button_entrar);
        btn_entrar.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if(v == btn_entrar) {
            Intent i = new Intent(this, Tela02.class);
            startActivity(i);
        }

    }
}